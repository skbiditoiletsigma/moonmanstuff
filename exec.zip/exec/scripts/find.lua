local nigger = {}

function nigger.find()
    name = "ryley"
    print(name.."is a nigger!")
end

while true do
    nigger.find()
    task.wait(0.1)
end